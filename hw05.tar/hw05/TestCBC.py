import CBC

#============================================================
# Checking the padding functions
#============================================================
def test():
    print("Checking the padding functions...")

    m = open("M.txt", "rb").read()
    mpad1 = open("M-padded1.txt", "rb").read()
    mpad2 = open("M-padded2.txt", "rb").read()
    mpad3 = open("M-padded3.txt", "rb").read()

    p = CBC.add_padding(m)
    if p == None:
        print("add_padding returned None")
        return
    if p != mpad1:
        print("error: add_padding is not correctly implemented")
        print("Expected:\t\t\t" + mpad1.hex())
        print("Received from add_padding:\t" + p.hex())
        return


    p = CBC.remove_padding(mpad1)
    if p == None:
        print("remove_padding returned None")
        return
    if p[0] != m:
        print("error (M-padded1.txt): remove_padding is not correctly implemented")
        print("Removing padding from:\t\t" + mpad1.hex())
        print("Expected:\t\t\t" + m.hex())
        print("Received from remove_padding:\t" + p[0].hex())
        return

    p = CBC.remove_padding(mpad2)
    if p == None:
        print("remove_padding returned None")
        return
    if p[1]:
        print("error (M-padded2.txt): remove_padding is not correctly implemented")
        print("Removing padding from: " + mpad2.hex())
        print("remove_padding returned True, it doesn't detect the wrong padding")
        print("This message is only 31 bytes, it is not the correct length")
        return

    p = CBC.remove_padding(mpad3)
    if p == None:
        print("remove_padding returned None")
        return
    if p[1]:
        print("error (M-padded3.txt): remove_padding is not correctly implemented")
        print("Removing padding from: " + mpad3.hex())
        print("remove_padding returned True, it doesn't detect the wrong padding")
        return

    #============================================================
    # Checking encrypt_basic
    #============================================================
    print("Checking encrypt_basic...")
    k = bytes.fromhex("00112233445566778899aabbccddeeff")
    iv = bytes.fromhex("0123456789abcdef0123456789abcdef")

    m = open("M-padded1.txt", "rb").read()
    c = open("M-padded1_cbc.bin", "rb").read()
    c2 = CBC.encrypt_basic(k, iv, m)

    if c2 == None:
        print("encrypt_basic returned None")
        return
    if c2 != c:
        print("error: encrypt_basic is not implemented correctly")
        print("Encrypting:\t\t" + m.hex())
        print("Expected:\t\t" + c.hex())
        print("encrypt_basic returned:\t" + c2.hex())
        return

    m = open("pic_original.bmp", "rb").read()
    c = open("pic_original_cbc.bin", "rb").read()
    if CBC.encrypt_basic(k, iv, m) != c:
        print("error: encrypt_basic is not implemented correctly, failed on BMP file")
        return


    #============================================================
    # Checking decrypt_basic
    #============================================================
    print("Checking decrypt_basic...")

    m = open("M-padded1.txt", "rb").read()
    c = open("M-padded1_cbc.bin", "rb").read()

    #open("test", "wb").write( CBC.decrypt_basic(k, iv, c) )
    m2 = CBC.decrypt_basic(k, iv, c)

    if m2 == None:
        print("decrypt_basic returned None")
        return

    if m2 != m:
        print("error: decrypt_basic is not implemented correctly")
        print("check: you should output a bytes object")
        print("Decrypting:\t\t\t" + c.hex())
        print("Expected:\t\t\t" + m.hex())
        print("Received from decrypt_basic:\t" + m2.hex())
        return

    m = open("pic_original.bmp", "rb").read()
    c = open("pic_original_cbc.bin", "rb").read()

    if CBC.decrypt_basic(k, iv, c) != m:
        print("error: decrypt_basic is not implemented correctly, failed on BMP")
        print("check: you should output a bytes object")
        return

    c1 = open("cbc2.out", "rb").read()
    if CBC.decrypt_basic(k, iv, c1) != b'':
        print("error: decrypt_basic is not implemented correctly")
        print("it doesn't detect wrong paddings")
        print("Should return an empty bytes object on incorrect padding")
        return

    #============================================================
    # Checking encrypt/decrypt
    #============================================================
    print("Checking encrypt/decrypt...")
    c2 = CBC.encrypt(k,m)
    c3 = CBC.encrypt(k,m)
    if c2 == c3:
        print("error: encrypt is not randomized")
        print("choose iv at random every time")
        return

    if CBC.decrypt(k,c2) != m:
        print("error: decrypt is not implemented correctly")
        return

    if CBC.decrypt(k,c3) != m:
        print("error: decrypt is not implemented correctly")
        return

    if CBC.decrypt(k, iv + c) != m:
        print("error: decrypt is not implemented correctly")
        return

    if CBC.decrypt(k, iv + c1) != bytes():
        print("error: decrypt is not implemented correctly")
        print("it doesn't detect wrong paddings")
        return

    print("Good!")


test()
